from django.db import models

# Create your models here.

class Favors(models.Model):
    title = models.CharField(max_length=200, verbose_name='Название услуги')
    image = models.ImageField(upload_to='imagess', blank=True, null=True, verbose_name='Картинка')
    desc = models.CharField(max_length=200, blank=True, null=True, verbose_name='Описание')

    def str(self):
        return self.title

    class Meta:
        verbose_name_plural = 'Услуги'
        verbose_name = 'Услуги'
