from modeltranslation.translator import register, TranslationOptions
from .models import *

@register(Favors)
class FavorsTranslationOptions(TranslationOptions):
    fields = ('title', 'desc',)
