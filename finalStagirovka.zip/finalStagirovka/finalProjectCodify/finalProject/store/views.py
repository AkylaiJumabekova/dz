from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.conf import settings

from .models import *

def home(request):
    favors = Favors.objects.all()
    context = {"favors": favors}
    return render(request, "index.html", context)

def services(request):
    return render(request, "services.html")

def shop(request):
    return render(request, "team.html")

def contact(request):
    return render(request, "contact.html")

def about(request):
    return render(request, "about.html")

def about(request):
    return render(request, "booking.html")

def about(request):
    return render(request, "destimonial.html")